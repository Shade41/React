import React, { Component } from 'react';
import './App.css';
import Menu from './menu/Menu'
import ShoppingList from './shopping-list/ShoppingList'
import { BrowserRouter as Router, Switch, Route,} from 'react-router-dom';
import AddItem from './item-add/AddItem';


class App extends Component {
  render() {
    return (
        <Router>
             <div>
                <Menu />
                <div className="app container">
                  <Switch>
                      <Route path='/add' component={AddItem} />
                      <Route path='/'  component={ShoppingList} />
                  </Switch>
                </div>
              </div>
        </Router>

    );
  }
}

export default App;
