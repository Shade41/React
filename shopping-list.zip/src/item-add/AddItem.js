import React from 'react';
import './AddItem.css'
class AddItem extends React.Component{

    constructor(props){
        super(props)
        this.state = {
            name: '',
            price: 0
        }
    }

    handleSubmit(event){
        event.preventDefault();
        const state = this.state
        fetch('http://localhost:3000/api/items', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                name: state.name,
                price: state.price
            })
        }).then(result =>{
            this.props.history.push("/")
        });
       
    }

    handleChange(event,key){
        this.setState({
            [key]: event.target.value
        });
    }

    render(){
       
        return(
          <div className="centered">
            <h2>Pridaj položku</h2>
            <form onSubmit={this.handleSubmit.bind(this)}>
              <label for="name"> Názov:</label>
              <input type="text" name="name" onChange={(event) => this.handleChange(event,"name")} value={this.state.name}/>
              <br/>
              <label for="price">Cena:</label>    
              <input type="text" name="price" onChange={(event) => this.handleChange(event,"price")} value={this.state.price}/>
              <br/>
              <button type="submit" className="btn btn-default" id="add-button-form" value="Pridaj"><i className="far fa-plus-square mr-1"></i>Pridaj</button>
            </form>
          </div>
       );
    }
}

export default AddItem; 