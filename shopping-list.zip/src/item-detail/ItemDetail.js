import React from 'react'


class ItemDetail extends React.Component{
    
   constructor(props){
       super(props);
       this.state = {
           item : null
       }
   }
    componentDidMount(){
        this.loadData();
    }

    componentDidUpdate(){
        
        this.loadData();
    }

    loadData(){
        const itemId = this.props.match.params.id;
        if((!this.state.item) || (this.state.item && (itemId != this.state.item.id))){
            fetch('http://localhost:3000/api/items/' + itemId)
            .then(result=>result.json())
            .then(resp=>this.setState({
                item: {
                    id: resp.data.id,
                    name: resp.data.name,
                    price: resp.data.price
                }
            }));
        }
    }
    render(){
        let itemDetail = (<p>Načítavam</p>);
        if(this.state.item){
            itemDetail = (
                <div>
                    <div className="row">
                    <div className="col-sm-12"><h2>{this.state.item.name}</h2></div> 
                    </div>
                    <div className="row">
                        <div className="col-sm-6"><b>ID:</b></div> <div className="col-sm-6">{this.state.item.id}</div>  
                    </div>
                    <div className="row">
                    <div className="col-sm-6"><b>Cena:</b></div>  <div className="col-sm-6">{this.state.item.price} &euro;</div> 
                    </div>
                </div>
            );
        }
        return(
            <div>
           {itemDetail}
           </div> 
        );
    }
}
 
export default ItemDetail;