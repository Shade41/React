class ItemDetail extends React.Component{
    
    constructor(props){
        super(props);
        this.state = { item : null, text: 'AAA' }
    }
     componentDidMount(){
        this.setState({item:{
                id: 15
            }});
     }
 
     render(){
         let itemDetail = (<p>Načítavam</p>);
         if(this.state.item){
             itemDetail = (
                    <div>
                         <div>{this.state.text}</div>
                         <div>{this.state.item.id}</div>  
                     </div>
             );
         }
         return(<div>
            {itemDetail}
            </div>);
     }
 }
  
 export default ItemDetail;