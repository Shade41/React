import React from 'react'
import { MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBCollapse} from "mdbreact";

class Menu extends React.Component{
    
    constructor(props){
        super(props);
        this.active = 1;
        this.state = {
            active : 1
        }
    }
    
    
    handleMenuClick(id){
        this.setState({
            active: id
        })
    }

    render(){
        return (
                <MDBNavbar color="indigo" dark expand="md">
                    <MDBNavbarBrand>
                        <strong className="white-text">Nákupný zoznam</strong>
                    </MDBNavbarBrand>
                    <MDBCollapse id="navbarCollapse3" isOpen={true} navbar>
                        <MDBNavbarNav left>
                            <MDBNavItem active= {this.state.active === 1} onClick = {this.handleMenuClick.bind(this,1)}>
                                <MDBNavLink className="far fa-list-alt" to="/"> Zoznam</MDBNavLink>
                            </MDBNavItem>
                            <MDBNavItem active= {this.state.active === 2} onClick = {this.handleMenuClick.bind(this,2)}>
                                <MDBNavLink className="far fa-plus-square" to="/add"> Pridaj položku</MDBNavLink>
                            </MDBNavItem>
                        </MDBNavbarNav>
                    </MDBCollapse>      
                </MDBNavbar>
        );
    }
}
 
export default Menu;