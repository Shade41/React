import React from 'react';
import ListItem from './list-item/ListItem';
import ListHeader from './list-header/ListHeader';
import './ShoppingList.css'
import ItemDetail from '../item-detail/ItemDetail';
import {Route, withRouter} from 'react-router-dom';

class ShoppingList extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            items: []
        };
    }

    componentDidMount(){
        this.getItemsFromServer();
    }

    getItemsFromServer(){
        fetch('http://localhost:3000/api/items')
            .then(result=>result.json())
            .then(resp=>this.setState({items: resp.data}));
    }

    handleClickDelete(id){
      
        fetch('http://localhost:3000/api/items/' + id, {
            method: 'DELETE',
        })
        .then(res => res.json())
        .then(res => {
            this.getItemsFromServer();
            console.log(res)}
        );

        
    }

    render(){
        const itemsComponents = this.state.items.map((item) =>
            <ListItem name={item.name} price={item.price} clickDelete={this.handleClickDelete.bind(this, item.id)} id={item.id} key={item.id}/>
        );
        let sucet = 0;
        this.state.items.forEach(element => {
            sucet = sucet + parseFloat(element.price);    
        });
        
        console.log(this.props.match.url);
        return(
           <div className="row">
                <div className="col-sm-6">
                    <ListHeader/>
                    {itemsComponents}
                    <hr></hr>
                    <div className="row">
                        <div className="col-sm-4">Súčet</div>
                        <div className="col-sm-2">{sucet} &euro;</div>
                    </div>
                </div>
                <div className="col-sm-6">
                      <Route path={this.props.match.url +  ':id'} exact component={ItemDetail} />
                </div>
                 
           </div>
       );
    }
}

export default withRouter(ShoppingList); 