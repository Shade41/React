import React from 'react'
import './ListHeader.css'

const ListHeader = () => {
  return (
    <div className="row header">
        <div className="col-sm-4">Názov</div>
        <div className="col-sm-2">Cena</div>
        <div className="col-sm-3"></div>
        <div className="col-sm-3"></div>
    </div>
  )
}
 
export default ListHeader;