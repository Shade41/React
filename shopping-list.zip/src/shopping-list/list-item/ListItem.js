import React from 'react';
import './ListItem.css';
import {NavLink, withRouter}  from 'react-router-dom';


const ListItem = (props) => {
    console.log(props.match.url)
    return(
      
      <div className="row list-item">
          <div className="col-sm-4">{props.name}</div>
          <div className="col-sm-2">{props.price} &euro;</div>
          <div className="col-sm-1">
            <i className="fas fa-trash-alt" onClick={props.clickDelete}></i>
          </div>
          <div className="col-sm-1">
            <NavLink to={props.match.url +`${props.id}`} className="fas fa-arrow-circle-right"></NavLink>
          </div>
      </div>
    )
}

 
export default withRouter(ListItem);